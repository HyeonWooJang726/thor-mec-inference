# Rate / GPC frequency Gate

**Stopped: PRIMARY_RUN_INVALID_OC3.** Both smokes passed; first primary run
encountered OC3 at active +16.695 s. Primary valid 0/36, sanity 0/9; all three
Gates INCONCLUSIVE. No retry. See gate_verdict.md and the retained failed run.

Engine provenance and active-load GPC switching PASS. MAXN fixed; supported Gate
points 945/1260/1575 MHz. Available minimum is 54 MHz; default allowed range is
315–1575 MHz. frequency_capability.json preserves the original permission stop,
user-reported manual verification, and the measured successful microcheck.

EXPERIMENT_PLAN.md is frozen before smoke/primary outcomes and includes all
input/source hashes, balanced order, thresholds and repeat interpretation.
Run `python3 -B scripts/rate_dvfs_gate/run_rate_dvfs_gate.py smoke`, then `primary`
only if both smokes pass. Hardware execution requires the same authorized host
sysfs/GPU access used by the microcheck. No sudo or package changes.
Replaying `python3 -B scripts/rate_dvfs_gate/analyze_rate_dvfs_gate.py` reads raw
artifacts only. The helper supports inspect, set 945/1260/1575 (holds until signal
then restores), and restore. Scoped pinning restores on normal/exception/signal exit.

Cleanup: zero deletions; protected historical inventories are recorded in
cleanup_manifest.json. Engine is an ignored symlink to the unchanged canonical
main-worktree artifact. No historical implementation was edited.

Pre-primary verification: actual engine hash matches formal evidence; all seven
inputs verified by hash/ffprobe; active switching microcheck PASS/OC3 delta zero;
fixture tests passed safe write ordering, exception/SIGINT restore, active/drain
accounting, constant-power integration, constant-Q slope and invalidation for
OC3/frequency mismatch. Fixture values were never saved as experimental results.
