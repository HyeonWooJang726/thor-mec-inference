# Rate/DVFS Gate verdict

**Stop reason: PRIMARY_RUN_INVALID_OC3**

Final coupling verdict: **INCONCLUSIVE**. RATE_DVFS_GATE_PASS is not established.

## Workspace and preservation

Worktree `/home/ainet/research/thor-mec-rate-dvfs-gate`; branch `rate-dvfs-gate`.
No new worktree/branch. Zero clutter deletions. Present Static-C Formal,
Dynamic-C, canonical C2 and cleanup-review files match their previously recorded
inventory hashes. Historical implementations are unchanged. The main worktree
was read only for the canonical engine; its artifact is linked, not rebuilt.

## Capability and engine

Canonical engine SHA256 matches formal metadata:
`9d01cdb2838bb1b9db58c246e6111a5dccee63bb937b673fb48caf43e53bc5ff`.
The ignored local models symlink points to the verified main-worktree engine.

Available frequencies: 54–1575 MHz inclusive, step 9 MHz (170 points).
Available minimum 54 MHz is distinct from default allowed minimum 315 MHz.
Selected LOW/MID/HIGH: 945/1260/1575 MHz. Same-user write access was confirmed
outside the execution sandbox; no sudo was used.

Active-load microcheck LOW→MID→HIGH→LOW: PASS; requested bounds and nonzero
actual cur_freq matched each target. Command-to-first-observed delays:
12.531, 23.346, 57.450, 33.789 ms respectively. These are host-observed delays
including command processing and polling, not isolated hardware settling latency.
Each state has 94 active target samples in the preserved record. OC3 delta zero.
Idle cur_freq=0 was never treated as frequency-control failure.

## Smoke evidence — excluded from primary results

| Run | K/C/r/frequency | Source | Admitted | Completed including drain | Integrity | OC3 delta |
|---|---|---:|---:|---:|---|---:|
| RDVG_20260919_SMOKE01 | 7/4/30/1575 MHz | 2100 | 2100 | 2100 | VALID | 0 |
| RDVG_20260919_SMOKE02 | 7/4/21/945 MHz | 2100 | 1470 | 1470 | VALID | 0 |

Both retained 120 distinct warm-up records, requested/actual clock observations,
power/temperature traces, exact admitted identities and clean bounded-source
shutdown. Both restored the default frequency range. Smoke queue classifications
and performance do not establish primary stability or Gate PASS.

## Primary stop

The first frozen primary condition was K7/C4/r21/HIGH (1575 MHz), run
`RDVG_20260919_P01`. OC3 increased **0→1** at the first observed event timestamp
**16.695326666 s after active start**. That telemetry sample reports requested
and actual frequency 1575 MHz. The timestamp bounds observation, not the precise
hardware event instant. The cause of OC3 is not established by this observation.

The runner stopped and retained all five required artifacts. It recorded 3507
source frames, 2450 admitted frames, and 2450 completions, plus 120 warm-up
samples. The source count/trace coverage are incomplete relative to the planned
60 seconds because of this stop; those additional integrity errors are preserved.
They do not establish an independent frame-loss cause. No automatic retry occurred.

Execution counts: primary attempted **1/36**, valid primary **0/36**; sanity
**0/9**. All unexecuted conditions remain unmeasured. There is no valid primary
operating map for completed FPS, per-stream FPS, queue slope, power or energy.
The canonical CSVs retain smoke diagnostics and the explicitly INVALID/incomplete
primary row. In particular, the invalid run's count/planned-60-second diagnostic
ratios are not sustained throughput measurements and are not used in any Gate
comparison. Active energy/average power are unavailable for its incomplete trace.

| Gate | Verdict | Reason |
|---|---|---|
| ADMISSION_GATE | INCONCLUSIVE | No valid primary conditions |
| FREQUENCY_CAPACITY_GATE | INCONCLUSIVE | Switching works; sustainable-capacity matrix unmeasured |
| ENERGY_OPPORTUNITY_GATE | INCONCLUSIVE | No valid matched LOW/HIGH primary or sanity conditions |

Final postflight: MAXN maintained; governor nvhost_podgov unchanged; GPC min/max
restored to **315000000/1575000000 Hz**. Plan and frozen source hashes verified
unchanged after the stop. No thresholds, admission/frequency points, repeats or
control variables were changed. No energy model fit or controller was attempted.

Any future retry requires diagnosis of the OC3 cause, explicit retry rationale,
and a distinct run ID; the failed run must remain preserved.
