#!/usr/bin/env python3
"""Replay canonical raw Gate records; no GPU or clock access."""
import argparse
import csv
import gzip
import json
from pathlib import Path
import statistics

import numpy as np


def read_csv(path):
    with gzip.open(path, 'rt', newline='') as source:
        return list(csv.DictReader(source))


def quantiles(values):
    if not values:
        return {key: None for key in ('mean','p50','p95','p99')}
    return dict(zip(('mean','p50','p95','p99'),
                    [float(np.mean(values)), *map(float,np.percentile(values,[50,95,99]))]))


def queue_slope(frames, start_ns, end_ns):
    """Exact continuous-time OLS slope of the reconstructed step queue.

    Sum each admitted request's waiting indicator integral. Uniform time
    weighting avoids bias from differing numbers of enqueue/start events.
    """
    duration = (end_ns-start_ns)/1e9
    numerator = 0.0
    for row in frames:
        a = max(int(row['enqueue_timestamp_ns']), start_ns)
        b = min(int(row['inference_start_timestamp_ns']), end_ns)
        if b > a:
            left, right = (a-start_ns)/1e9-duration/2, (b-start_ns)/1e9-duration/2
            numerator += (right*right-left*left)/2
    return numerator/(duration**3/12)


def summarize(manifest, frames, power):
    errors = list(manifest.get('errors', []))
    active = [r for r in frames if r['phase']=='active']
    admitted = [r for r in active if int(r['admitted'])]
    finished = [r for r in admitted if r.get('completion_timestamp_ns')]
    t0, t1 = manifest.get('active_start_ns'), manifest.get('active_end_ns')
    summary = {'run_id':manifest['run_id'], 'kind':manifest['kind'],
               'K':manifest['K'],'C':manifest['C'], 'freq_state':manifest['freq_state'],
               'requested_freq_MHz':manifest['requested_freq_MHz'],
               'admission_fps_per_stream':manifest['admission_fps_per_stream'],
               'source_frames':len(active),'admitted_frames':len(admitted),
               'completed_frames_including_drain':len(finished),
               'errors':errors, 'provenance':'measured',
               'power_scope':'GPU rail VDD_GPU (tegrastats instantaneous channel)',
               'queue_definition':'admission/enqueue <= t < inference service start; includes front-end backlog'}
    if t0 is None or t1 is None:
        errors.append('active interval unavailable')
        summary.update(validity='INVALID',queue_stable=False)
        return summary
    duration = (t1-t0)/1e9
    active_finished = [r for r in finished if t0 <= int(r['completion_timestamp_ns']) < t1]
    expected = int(duration*30)
    per_stream=[]
    for stream in range(manifest['K']):
        rows=[r for r in active if int(r['stream_id'])==stream]
        if sorted(int(r['frame_id']) for r in rows) != list(range(expected)):
            errors.append(f'stream {stream}: source identity/count mismatch')
        acc=0
        for row in sorted(rows,key=lambda r:int(r['frame_id'])):
            acc += manifest['admission_fps_per_stream']
            decision = acc >=30
            if decision: acc-=30
            if bool(int(row['admitted'])) != decision:
                errors.append(f'stream {stream}: deterministic admission mismatch')
                break
        selected=[r for r in admitted if int(r['stream_id'])==stream]
        complete=[r for r in active_finished if int(r['stream_id'])==stream]
        rate=len(complete)/duration
        per_stream.append({'stream_id':stream,'source_frames':len(rows),
                           'admitted_frames':len(selected),'completed_active':len(complete),
                           'R_k':rate,'eta_k':rate/30,
                           'g_Q_k':None})
    if len(finished)!=len(admitted): errors.append('admitted/completed drain accounting mismatch')
    if manifest.get('warmup_inferences_per_worker'):
        warm=[r for r in frames if r['phase']=='warmup']
        if len(warm)!=manifest['C']*manifest['warmup_inferences_per_worker'] or any(not r.get('completion_timestamp_ns') for r in warm):
            errors.append('warm-up accounting mismatch')
    if manifest.get('clean_shutdown') is False:
        errors.append('unclean shutdown')
    for row in admitted:
        names=('logical_arrival_ns','enqueue_timestamp_ns','b_ns','ready_timestamp_ns',
               'inference_start_timestamp_ns','completion_timestamp_ns')
        if any(row.get(n) in (None,'') for n in names):
            errors.append('missing admitted-frame timestamps'); break
        stamps=[int(row[n]) for n in names]
        if stamps!=sorted(stamps):
            errors.append('frame timestamp ordering mismatch'); break
        if not t0 <= stamps[1] < t1:
            errors.append('admission outside active interval'); break
    for row in active:
        if not int(row['admitted']) and any(row.get(n) not in (None,'') for n in
             ('enqueue_timestamp_ns','inference_start_timestamp_ns','completion_timestamp_ns')):
            errors.append('skipped frame entered inference queue'); break
        if not row.get('source_timestamp_ns') or not row.get('source_pulled_ns'):
            # PTS zero is represented as integer 0 or string '0', both valid.
            if row.get('source_timestamp_ns') not in (0,'0') or not row.get('source_pulled_ns'):
                errors.append('source frame decode record missing'); break
    for stream in range(manifest['K']):
        pts=[int(r['source_timestamp_ns']) for r in sorted(active,key=lambda r:int(r['frame_id']))
             if int(r['stream_id'])==stream and r.get('source_timestamp_ns') not in ('',None)]
        if any(b<=a for a,b in zip(pts,pts[1:])): errors.append(f'stream {stream}: source PTS identity not increasing')
    if manifest.get('queue_overflow') or manifest.get('forced_drop') or manifest.get('queue_cap_saturation'):
        errors.append('queue overflow/drop/cap saturation')
    summary.update(aggregate_admitted_fps=len(admitted)/duration,
                   aggregate_completed_fps=len(active_finished)/duration,
                   completed_active_frames=len(active_finished),
                   min_per_stream_completed_fps=min(p['R_k'] for p in per_stream),
                   mean_per_stream_completed_fps=statistics.mean(p['R_k'] for p in per_stream),
                   per_stream=per_stream,measurement_seconds=duration)
    if len(finished)==len(admitted) and all(r.get('inference_start_timestamp_ns') for r in admitted):
        slope_start=t1-int(min(30,duration/2)*1e9)
        slopes=[]
        for p in per_stream:
            rows=[r for r in admitted if int(r['stream_id'])==p['stream_id']]
            p['g_Q_k']=queue_slope(rows,slope_start,t1)
            slopes.append(p['g_Q_k'])
        summary['aggregate_queue_slope']=sum(slopes)
        summary['max_per_stream_queue_slope']=max(slopes)
        events=[]
        for row in admitted:
            events.extend([(int(row['enqueue_timestamp_ns']),1),(int(row['inference_start_timestamp_ns']),-1)])
        depth=0; peak=0; end_queue=0
        for stamp,delta in sorted(events):
            depth+=delta
            if depth<0: errors.append('negative reconstructed physical queue')
            peak=max(peak,depth)
            if stamp<t1: end_queue=depth
        if depth: errors.append('nonzero queue after drain')
        summary.update(queue_peak=peak,queue_at_active_end=end_queue,
                       queue_wait_ms=quantiles([(int(r['inference_start_timestamp_ns'])-int(r['enqueue_timestamp_ns']))/1e6 for r in finished]),
                       service_ms=quantiles([(int(r['completion_timestamp_ns'])-int(r['inference_start_timestamp_ns']))/1e6 for r in finished]),
                       latency_ms=quantiles([(int(r['completion_timestamp_ns'])-int(r['logical_arrival_ns']))/1e6 for r in finished]))
    else:
        summary.update(aggregate_queue_slope=None,max_per_stream_queue_slope=None)
    try:
        ordered=sorted(power,key=lambda r:int(r['timestamp_ns']))
        stamps=np.array([(int(r['timestamp_ns'])-t0)/1e9 for r in ordered])
        watts=np.array([float(r['measured_power_W']) for r in ordered])
        if len(stamps)<2 or stamps[0]>0 or stamps[-1]<duration or np.any(np.diff(stamps)<=0):
            raise ValueError('power trace does not bracket active interval or is nonmonotonic')
        inside=(stamps>0)&(stamps<duration)
        xs=np.concatenate(([0.],stamps[inside],[duration]))
        ys=np.concatenate(([np.interp(0,stamps,watts)],watts[inside],[np.interp(duration,stamps,watts)]))
        if np.max(np.diff(xs))>.5 or not np.isfinite(ys).all() or np.any(ys<0):
            raise ValueError('power trace gap >0.5 s or invalid measured power')
        energy=float(np.trapz(ys,xs))
        active_power=[r for r in ordered if t0<=int(r['timestamp_ns'])<=t1]
        actual=[float(r['actual_gpu_freq_MHz']) for r in active_power if float(r['actual_gpu_freq_MHz'])>0]
        if not actual: errors.append('FREQUENCY_READBACK_UNAVAILABLE')
        if any(f!=manifest['requested_freq_MHz'] for f in actual): errors.append('active actual frequency mismatch')
        for sec in range(int(duration)):
            if not any(t0+sec*10**9<=int(r['timestamp_ns'])<t0+(sec+1)*10**9 and float(r['actual_gpu_freq_MHz'])>0 for r in active_power):
                errors.append(f'active frequency readback missing in second {sec}')
        if any(int(r['min_freq_Hz'])!=manifest['requested_freq_MHz']*10**6 or
               int(r['max_freq_Hz'])!=manifest['requested_freq_MHz']*10**6 for r in active_power):
            errors.append('requested range not maintained')
        counts=[int(r['OC3_count']) for r in ordered]
        delta=manifest.get('OC3_after',max(counts))-manifest.get('OC3_before',min(counts))
        if delta or max(counts)!=min(counts): errors.append('OC3 event')
        summary.update(avg_power_W=energy/duration,active_energy_J=energy,
                       actual_freq_mean_MHz=statistics.mean(actual) if actual else None,
                       actual_freq_mean_scope='nonzero active-interval observations',
                       temperature=statistics.mean(float(r['temperature_C']) for r in active_power),
                       OC3_delta=delta)
    except (ValueError,KeyError,TypeError) as error:
        errors.append(f'measurement trace: {error}')
    summary['validity']='VALID' if not errors else 'INVALID'
    summary['queue_stable']=bool(not errors and summary['aggregate_queue_slope']<=.5 and summary['max_per_stream_queue_slope']<=.2)
    summary['queue_classification']=('INVALID' if errors else 'QUEUE_STABLE' if summary['queue_stable'] else 'UNSTABLE')
    summary['energy_per_frame_J']=(summary['active_energy_J']/len(active_finished)
                                  if summary['queue_stable'] and active_finished else None)
    return summary


FIELDS=['K','C','freq_state','requested_freq_MHz','actual_freq_mean_MHz','admission_fps_per_stream',
        'aggregate_admitted_fps','aggregate_completed_fps','min_per_stream_completed_fps',
        'mean_per_stream_completed_fps','aggregate_queue_slope','max_per_stream_queue_slope',
        'queue_stable','avg_power_W','active_energy_J','energy_per_frame_J','temperature','OC3_delta','validity']


def write_csv(path,fields,rows):
    with path.open('w',newline='') as target:
        writer=csv.DictWriter(target,fieldnames=fields,extrasaction='ignore')
        writer.writeheader();writer.writerows(rows)


def aggregate(root):
    summaries=[]
    for directory in sorted(root.glob('RDVG_*')):
        if not (directory/'manifest.json').exists(): continue
        manifest=json.loads((directory/'manifest.json').read_text())
        summary=summarize(manifest,read_csv(directory/'per_frame.csv.gz'),read_csv(directory/'power_trace.csv.gz'))
        (directory/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        summaries.append(summary)
    write_csv(root/'aggregate_summary.csv',['run_id','kind']+FIELDS+['queue_classification'],summaries)
    groups={}
    for s in summaries:
        if s['kind'] not in ('primary','sanity'): continue
        key=(s['K'],s['C'],s['freq_state'],s['admission_fps_per_stream'])
        groups.setdefault(key,[]).append(s)
    cells=[]
    for (k,c,f,r),runs in sorted(groups.items()):
        cell=dict(K=k,C=c,freq_state=f,admission_fps_per_stream=r,repetitions=len(runs))
        complete=len(runs)==3 and all(s['validity']=='VALID' for s in runs)
        flags=[s['queue_stable'] for s in runs]
        cell['validity']='VALID' if complete else 'INCOMPLETE_OR_INVALID'
        cell['queue_stable']=('QUEUE_STABLE' if all(flags) else 'UNSTABLE' if not any(flags) else 'MIXED') if complete else 'INCONCLUSIVE'
        for field in FIELDS:
            if field in cell: continue
            vals=[s.get(field) for s in runs]
            cell[field]=statistics.mean(vals) if all(isinstance(v,(int,float)) for v in vals) else None
        cells.append(cell)
    write_csv(root/'operating_map.csv',FIELDS+['repetitions'],cells)
    lookup={(x['K'],x['freq_state'],x['admission_fps_per_stream']):x for x in cells}
    def stable(cell): return cell and cell['queue_stable']=='QUEUE_STABLE'
    def unstable(cell): return cell and cell['queue_stable']=='UNSTABLE'
    witnesses={'ADMISSION_GATE':[],'FREQUENCY_CAPACITY_GATE':[],'ENERGY_OPPORTUNITY_GATE':[]}
    for freq in ('LOW','MID','HIGH'):
        base=lookup.get((7,freq,30))
        for r in (21,24,27):
            candidate=lookup.get((7,freq,r))
            if unstable(base) and stable(candidate) and candidate['aggregate_completed_fps']>=.95*base['aggregate_completed_fps']:
                witnesses['ADMISSION_GATE'].append(f'K7 {freq}: r30 UNSTABLE -> r{r} stable, throughput >=95%')
    for r in (21,24,27,30):
        low,high=lookup.get((7,'LOW',r)),lookup.get((7,'HIGH',r))
        if unstable(low) and stable(high): witnesses['FREQUENCY_CAPACITY_GATE'].append(f'K7 r{r}: LOW unstable, HIGH stable')
    boundaries={f:max([x['admission_fps_per_stream'] for x in cells if x['K']==7 and x['freq_state']==f and stable(x)],default=None) for f in ('LOW','HIGH')}
    if all(v is not None for v in boundaries.values()) and boundaries['HIGH']-boundaries['LOW']>=3:
        witnesses['FREQUENCY_CAPACITY_GATE'].append(f'observed stable grid boundary: {boundaries}')
    for k,r in [(7,r) for r in (21,24,27,30)]+[(6,30)]:
        low,high=lookup.get((k,'LOW',r)),lookup.get((k,'HIGH',r))
        if stable(low) and stable(high) and abs(low['aggregate_completed_fps']-high['aggregate_completed_fps'])/high['aggregate_completed_fps']<=.02 and low['avg_power_W']<=.9*high['avg_power_W']:
            witnesses['ENERGY_OPPORTUNITY_GATE'].append(f'K{k} r{r}: throughput within 2%, LOW power <=90% HIGH')
    primary_complete=sum(x['K']==7 and x['validity']=='VALID' and x['queue_stable']!='MIXED' for x in cells)==12
    sanity_complete=sum(x['K']==6 and x['validity']=='VALID' and x['queue_stable']!='MIXED' for x in cells)==3
    verdicts={gate:('PASS' if evidence else 'FAIL' if primary_complete and (gate!='ENERGY_OPPORTUNITY_GATE' or sanity_complete) else 'INCONCLUSIVE') for gate,evidence in witnesses.items()}
    final='RATE_DVFS_GATE_PASS' if all(v=='PASS' for v in verdicts.values()) and primary_complete and sanity_complete else ', '.join(k+'_FAIL' for k,v in verdicts.items() if v=='FAIL') or 'INCONCLUSIVE'
    lines=['# Rate/DVFS Gate verdict','',f'Final: **{final}**','',
           'Repeat rule: all three valid repeats must agree on stability; compare arithmetic condition means. Missing/invalid/mixed conditions remain inconclusive.','',
           '| Gate | Verdict |','|---|---|']+[f'| {k} | {v} |' for k,v in verdicts.items()]
    for gate,evidence in witnesses.items():
        lines.extend(['',f'{gate} evidence:']+(['- '+x for x in evidence] or ['- No qualifying measured witness.']))
    invalid=[s for s in summaries if s['validity']!='VALID']
    lines.extend(['','Invalid runs (retained; no retry):']+(['- '+s['run_id']+': '+ '; '.join(s['errors']) for s in invalid] or ['- None.']))
    lines.extend(['',f'Primary runs observed: {sum(s["kind"]=="primary" for s in summaries)}/36; sanity: {sum(s["kind"]=="sanity" for s in summaries)}/9.',
                  'Power is measured VDD_GPU rail power. Active energy excludes drain. E/frame is reported only for queue-stable runs.',
                  'See operating_map.csv for measured condition means and aggregate_summary.csv for individual runs.'])
    (root/'gate_verdict.md').write_text('\n'.join(lines)+'\n')
    return verdicts


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2]/'results/rate_dvfs_gate')
    args=parser.parse_args()
    print(json.dumps(aggregate(args.root)))
